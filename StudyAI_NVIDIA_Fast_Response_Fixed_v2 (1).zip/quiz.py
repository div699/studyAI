import db, llm_client

def generate(uid,did,count,difficulty):
    chunks=db.get_chunks(did)
    if not chunks: raise ValueError("This document has no readable content.")
    # Give the model a representative set while respecting the selected document.
    selected=chunks[:min(len(chunks), max(8, count))]
    cards=llm_client.quiz([c["text"] for c in selected],count,difficulty)
    if not isinstance(cards,list): raise ValueError("AI returned an invalid quiz.")
    qid=db.create_quiz(uid,did,difficulty,count)
    inserted=0
    for item in cards:
        opts=item.get("options",[])
        ci=item.get("correct_index")
        if len(opts)!=4 or not isinstance(ci,int) or not 0<=ci<4:
            continue
        source=selected[min(inserted,len(selected)-1)]
        db.insert_question(qid,item.get("question",""),opts,ci,item.get("explanation",""),source["id"],item.get("topic","General"))
        inserted+=1
        if inserted>=count: break
    if inserted==0: raise ValueError("The AI could not create valid questions. Try again.")
    return qid
