import sqlite3, time, json, os
from pathlib import Path

DB_PATH = Path(__file__).parent / "studyai.db"

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS profiles (
 user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 course TEXT DEFAULT 'TYBSc CS',
 preferred_language TEXT DEFAULT 'English',
 explanation_style TEXT DEFAULT 'Detailed',
 daily_minutes INTEGER DEFAULT 120,
 exam_date TEXT
);

CREATE TABLE IF NOT EXISTS documents (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL,
 created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS chunks (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
 chunk_index INTEGER NOT NULL,
 text TEXT NOT NULL,
 tfidf_json TEXT
);

CREATE TABLE IF NOT EXISTS chat_messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 document_id INTEGER REFERENCES documents(id) ON DELETE SET NULL,
 role TEXT NOT NULL,
 content TEXT NOT NULL,
 created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS notes (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 document_id INTEGER REFERENCES documents(id) ON DELETE SET NULL,
 title TEXT NOT NULL,
 content TEXT NOT NULL,
 created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS quizzes (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
 difficulty TEXT NOT NULL,
 question_count INTEGER NOT NULL,
 created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS quiz_questions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
 question TEXT NOT NULL,
 options_json TEXT NOT NULL,
 correct_index INTEGER NOT NULL,
 explanation TEXT NOT NULL,
 topic TEXT,
 source_chunk_id INTEGER REFERENCES chunks(id),
 student_answer INTEGER,
 answered_correct INTEGER
);

CREATE TABLE IF NOT EXISTS flashcards (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 document_id INTEGER REFERENCES documents(id) ON DELETE CASCADE,
 question TEXT NOT NULL,
 answer TEXT NOT NULL,
 difficulty TEXT DEFAULT 'medium',
 created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS study_plans (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 document_id INTEGER REFERENCES documents(id) ON DELETE SET NULL,
 start_date TEXT NOT NULL,
 days INTEGER NOT NULL,
 daily_minutes INTEGER NOT NULL,
 content_json TEXT NOT NULL,
 created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS activity_logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 activity_type TEXT NOT NULL,
 document_id INTEGER REFERENCES documents(id) ON DELETE SET NULL,
 topic TEXT,
 minutes INTEGER DEFAULT 0,
 metadata_json TEXT,
 created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS badges (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 code TEXT UNIQUE NOT NULL,
 name TEXT NOT NULL,
 description TEXT NOT NULL,
 threshold INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS user_badges (
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 badge_id INTEGER NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
 awarded_at REAL NOT NULL,
 PRIMARY KEY(user_id,badge_id)
);

CREATE TABLE IF NOT EXISTS topic_performance (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 topic TEXT NOT NULL,
 attempted INTEGER DEFAULT 0,
 correct INTEGER DEFAULT 0,
 UNIQUE(user_id,topic)
);
"""

BADGES = [
    ("streak10","Consistency Starter","10 consecutive active days",10),
    ("streak20","Dedicated Learner","20 consecutive active days",20),
    ("streak30","Study Champion","30 consecutive active days",30),
    ("quizmaster","Quiz Master","Average quiz accuracy of 90% or higher",90),
]

def get_conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    c=get_conn()
    c.executescript(SCHEMA)
    # Lightweight migration for databases created by an older StudyAI build.
    cols={r["name"] for r in c.execute("PRAGMA table_info(quiz_questions)").fetchall()}
    if "topic" not in cols:
        c.execute("ALTER TABLE quiz_questions ADD COLUMN topic TEXT")
    for b in BADGES:
        c.execute("INSERT OR IGNORE INTO badges(code,name,description,threshold) VALUES(?,?,?,?)", b)
    c.commit(); c.close()

def create_user(name,email,password_hash):
    c=get_conn()
    cur=c.execute("INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)",
                  (name,email.lower().strip(),password_hash,time.time()))
    uid=cur.lastrowid
    c.execute("INSERT INTO profiles(user_id) VALUES(?)",(uid,))
    c.commit(); c.close()
    return uid

def get_user_by_email(email):
    c=get_conn(); r=c.execute("SELECT * FROM users WHERE email=?",(email.lower().strip(),)).fetchone(); c.close(); return r

def get_user(uid):
    c=get_conn(); r=c.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone(); c.close(); return r

def get_profile(uid):
    c=get_conn(); r=c.execute("SELECT * FROM profiles WHERE user_id=?",(uid,)).fetchone(); c.close(); return r

def update_profile(uid, data):
    fields=["course","preferred_language","explanation_style","daily_minutes","exam_date"]
    vals=[data.get(f) for f in fields]
    c=get_conn()
    c.execute("""UPDATE profiles SET course=?,preferred_language=?,explanation_style=?,
                 daily_minutes=?,exam_date=? WHERE user_id=?""",(*vals,uid))
    c.commit(); c.close()

def create_document(uid,title):
    c=get_conn(); cur=c.execute("INSERT INTO documents(user_id,title,created_at) VALUES(?,?,?)",(uid,title,time.time()))
    c.commit(); did=cur.lastrowid; c.close(); return did

def list_documents(uid):
    c=get_conn(); r=c.execute("SELECT * FROM documents WHERE user_id=? ORDER BY created_at DESC",(uid,)).fetchall(); c.close(); return r

def get_document(uid,did):
    c=get_conn(); r=c.execute("SELECT * FROM documents WHERE id=? AND user_id=?",(did,uid)).fetchone(); c.close(); return r

def insert_chunks(did,texts):
    c=get_conn(); c.executemany("INSERT INTO chunks(document_id,chunk_index,text) VALUES(?,?,?)",
                                [(did,i,t) for i,t in enumerate(texts)])
    c.commit(); c.close()

def get_chunks(did):
    c=get_conn(); r=c.execute("SELECT * FROM chunks WHERE document_id=? ORDER BY chunk_index",(did,)).fetchall(); c.close(); return r

def save_chunk_vector(cid,vec):
    c=get_conn(); c.execute("UPDATE chunks SET tfidf_json=? WHERE id=?",(json.dumps(vec),cid)); c.commit(); c.close()

def add_chat(uid,did,role,content):
    c=get_conn(); c.execute("INSERT INTO chat_messages(user_id,document_id,role,content,created_at) VALUES(?,?,?,?,?)",
                             (uid,did,role,content,time.time())); c.commit(); c.close()

def chat_history(uid,did,limit=12):
    c=get_conn(); r=c.execute("""SELECT role,content FROM chat_messages
        WHERE user_id=? AND document_id IS ? ORDER BY created_at DESC LIMIT ?""",(uid,did,limit)).fetchall()
    c.close(); return list(reversed(r))

def create_note(uid,did,title,content):
    c=get_conn(); cur=c.execute("INSERT INTO notes(user_id,document_id,title,content,created_at) VALUES(?,?,?,?,?)",
                                (uid,did,title,content,time.time())); c.commit(); nid=cur.lastrowid; c.close(); return nid

def list_notes(uid):
    c=get_conn(); r=c.execute("SELECT n.*,d.title AS document_title FROM notes n LEFT JOIN documents d ON d.id=n.document_id WHERE n.user_id=? ORDER BY n.created_at DESC",(uid,)).fetchall(); c.close(); return r

def create_quiz(uid,did,difficulty,count):
    c=get_conn(); cur=c.execute("INSERT INTO quizzes(user_id,document_id,difficulty,question_count,created_at) VALUES(?,?,?,?,?)",
                                (uid,did,difficulty,count,time.time())); c.commit(); qid=cur.lastrowid; c.close(); return qid

def insert_question(qid,q,options,correct,explanation,chunk_id,topic="General"):
    c=get_conn(); c.execute("""INSERT INTO quiz_questions
      (quiz_id,question,options_json,correct_index,explanation,topic,source_chunk_id)
      VALUES(?,?,?,?,?,?,?)""",(qid,q,json.dumps(options),correct,explanation,topic,chunk_id))
    c.commit(); c.close()

def get_quiz(uid,qid):
    c=get_conn()
    quiz=c.execute("SELECT * FROM quizzes WHERE id=? AND user_id=?",(qid,uid)).fetchone()
    if not quiz: c.close(); return None,[]
    qs=c.execute("SELECT * FROM quiz_questions WHERE quiz_id=? ORDER BY id",(qid,)).fetchall()
    c.close(); return quiz,qs

def answer_question(uid,qid,qid2,answer):
    c=get_conn()
    row=c.execute("""SELECT qq.*,q.user_id FROM quiz_questions qq JOIN quizzes q ON q.id=qq.quiz_id
                     WHERE qq.id=? AND qq.quiz_id=? AND q.user_id=?""",(qid2,qid,uid)).fetchone()
    if not row: c.close(); return None
    correct=int(answer)==int(row["correct_index"])
    c.execute("UPDATE quiz_questions SET student_answer=?,answered_correct=? WHERE id=?",(answer,int(correct),qid2))
    c.commit(); c.close(); return correct

def log_activity(uid,typ,did=None,topic=None,minutes=0,metadata=None):
    c=get_conn(); c.execute("""INSERT INTO activity_logs(user_id,activity_type,document_id,topic,minutes,metadata_json,created_at)
        VALUES(?,?,?,?,?,?,?)""",(uid,typ,did,topic,minutes,json.dumps(metadata or {}),time.time())); c.commit(); c.close()

def update_topic(uid,topic,correct):
    if not topic: return
    c=get_conn()
    c.execute("""INSERT INTO topic_performance(user_id,topic,attempted,correct) VALUES(?,?,1,?)
                 ON CONFLICT(user_id,topic) DO UPDATE SET attempted=attempted+1,correct=correct+excluded.correct""",
              (uid,topic,int(correct)))
    c.commit(); c.close()

def topic_stats(uid):
    c=get_conn(); r=c.execute("""SELECT topic,attempted,correct,
        ROUND(100.0*correct/NULLIF(attempted,0),1) accuracy FROM topic_performance
        WHERE user_id=? ORDER BY accuracy ASC""",(uid,)).fetchall(); c.close(); return r

def streak(uid):
    c=get_conn()
    rows=c.execute("""SELECT DISTINCT date(created_at,'unixepoch','localtime') d FROM activity_logs
                     WHERE user_id=? ORDER BY d DESC""",(uid,)).fetchall()
    c.close()
    dates=[r["d"] for r in rows]
    if not dates: return 0,0
    import datetime
    ds=[datetime.date.fromisoformat(d) for d in dates]
    today=datetime.date.today()
    current=0
    if ds[0] in (today,today-datetime.timedelta(days=1)):
        expected=ds[0]
        for d in ds:
            if d==expected:
                current+=1; expected-=datetime.timedelta(days=1)
            else: break
    longest=0; run=0; prev=None
    for d in ds[::-1]:
        if prev is None or d==prev+datetime.timedelta(days=1): run+=1
        else: run=1
        longest=max(longest,run); prev=d
    return current,longest

def award_badges(uid):
    current,_=streak(uid)
    c=get_conn()
    for code,name,desc,threshold in BADGES[:3]:
        if current>=threshold:
            b=c.execute("SELECT id FROM badges WHERE code=?",(code,)).fetchone()
            c.execute("INSERT OR IGNORE INTO user_badges(user_id,badge_id,awarded_at) VALUES(?,?,?)",(uid,b["id"],time.time()))
    avg=c.execute("""SELECT COALESCE(ROUND(100.0*SUM(answered_correct)/NULLIF(COUNT(answered_correct),0),1),0)
                     FROM quiz_questions qq JOIN quizzes q ON q.id=qq.quiz_id
                     WHERE q.user_id=? AND qq.answered_correct IS NOT NULL""",(uid,)).fetchone()[0]
    if avg>=90:
        b=c.execute("SELECT id FROM badges WHERE code='quizmaster'").fetchone()
        c.execute("INSERT OR IGNORE INTO user_badges(user_id,badge_id,awarded_at) VALUES(?,?,?)",(uid,b["id"],time.time()))
    c.commit(); c.close()

def badges(uid):
    c=get_conn(); r=c.execute("""SELECT b.*,ub.awarded_at FROM user_badges ub JOIN badges b ON b.id=ub.badge_id
                                 WHERE ub.user_id=? ORDER BY ub.awarded_at DESC""",(uid,)).fetchall(); c.close(); return r

def dashboard(uid):
    c=get_conn()
    docs=c.execute("SELECT COUNT(*) n FROM documents WHERE user_id=?",(uid,)).fetchone()["n"]
    questions=c.execute("SELECT COUNT(*) n FROM chat_messages WHERE user_id=? AND role='user'",(uid,)).fetchone()["n"]
    study_minutes=c.execute("SELECT COALESCE(SUM(minutes),0) n FROM activity_logs WHERE user_id=?",(uid,)).fetchone()["n"]
    answered=c.execute("""SELECT COUNT(*) n FROM quiz_questions qq JOIN quizzes q ON q.id=qq.quiz_id
                          WHERE q.user_id=? AND qq.answered_correct IS NOT NULL""",(uid,)).fetchone()["n"]
    correct=c.execute("""SELECT COALESCE(SUM(answered_correct),0) n FROM quiz_questions qq JOIN quizzes q ON q.id=qq.quiz_id
                         WHERE q.user_id=?""",(uid,)).fetchone()["n"]
    avg=round(correct*100/answered) if answered else 0
    c.close()
    cur,longest=streak(uid); award_badges(uid)
    return {"documents":docs,"questions":questions,"study_minutes":study_minutes,"quiz_accuracy":avg,
            "current_streak":cur,"longest_streak":longest,"badges":[dict(x) for x in badges(uid)]}
