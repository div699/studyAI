import os, datetime, json, re
from functools import wraps
from pathlib import Path
from flask import Flask, request, jsonify, render_template, session, redirect, url_for, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

import db, ingest, retrieval, llm_client, quiz as quiz_module

load_dotenv()
app=Flask(__name__)
app.secret_key=os.getenv("SECRET_KEY","dev-secret-change-me")
MAX_UPLOAD_MB=int(os.getenv("MAX_UPLOAD_MB","20"))
db.init_db()

def uid():
    return session.get("user_id")

def login_required(fn):
    @wraps(fn)
    def wrapper(*args,**kwargs):
        user_id = uid()
        if not user_id:
            return jsonify({"error":"Please log in first."}),401
        # Protect against stale sessions after a database reset/replacement.
        if db.get_user(user_id) is None:
            session.clear()
            return jsonify({"error":"Your session expired. Please log in again."}),401
        return fn(*args,**kwargs)
    return wrapper

def require_doc(did):
    try: did=int(did)
    except: raise ValueError("Invalid document.")
    d=db.get_document(uid(),did)
    if not d: raise ValueError("Document not found or access denied.")
    return d

def context_for(did,query=None,limit=8):
    chunks=retrieval.query_index(did,query,limit) if query else db.get_chunks(did)[:limit]
    return chunks

@app.route("/")
def index():
    # A Flask session cookie can survive a database reset or replacement of the
    # project ZIP. In that case the session may contain a user_id that no longer
    # exists. Never pass None to dict(); clear the stale session and show login.
    user_id = uid()
    if not user_id:
        return render_template("index.html", authenticated=False, user=None)

    user = db.get_user(user_id)
    profile = db.get_profile(user_id)
    if user is None or profile is None:
        session.clear()
        return render_template("index.html", authenticated=False, user=None)

    return render_template(
        "index.html",
        authenticated=True,
        user=dict(user),
    )

@app.post("/api/auth/signup")
def signup():
    data=request.get_json(force=True)
    name=(data.get("name") or "").strip()
    email=(data.get("email") or "").strip().lower()
    password=data.get("password") or ""
    if len(name)<2 or "@" not in email or len(password)<8:
        return jsonify({"error":"Use a valid name, email and password of at least 8 characters."}),400
    if db.get_user_by_email(email): return jsonify({"error":"An account with this email already exists."}),409
    new_id=db.create_user(name,email,generate_password_hash(password))
    session["user_id"]=new_id
    return jsonify({"ok":True,"user":{"id":new_id,"name":name,"email":email}})

@app.post("/api/auth/login")
def login():
    data=request.get_json(force=True)
    u=db.get_user_by_email((data.get("email") or "").strip())
    if not u or not check_password_hash(u["password_hash"],data.get("password") or ""):
        return jsonify({"error":"Invalid email or password."}),401
    session["user_id"]=u["id"]
    return jsonify({"ok":True,"user":{"id":u["id"],"name":u["name"],"email":u["email"]}})

@app.post("/api/auth/logout")
def logout():
    session.clear()
    return jsonify({"ok":True})

@app.get("/api/me")
@login_required
def me():
    u=db.get_user(uid()); p=db.get_profile(uid())
    return jsonify({"user":dict(u),"profile":dict(p)})

@app.post("/api/profile")
@login_required
def save_profile():
    data=request.get_json(force=True)
    try: minutes=max(10,min(600,int(data.get("daily_minutes",120))))
    except: minutes=120
    data["daily_minutes"]=minutes
    db.update_profile(uid(),data)
    return jsonify({"ok":True})

@app.get("/api/documents")
@login_required
def documents():
    return jsonify({"documents":[dict(x) for x in db.list_documents(uid())]})

@app.post("/api/upload")
@login_required
def upload():
    f=request.files.get("file")
    if not f or not f.filename: return jsonify({"error":"Choose a file."}),400
    if len(f.read())>MAX_UPLOAD_MB*1024*1024: return jsonify({"error":f"Maximum file size is {MAX_UPLOAD_MB} MB."}),413
    f.stream.seek(0); raw=f.read()
    try: text=ingest.extract_text(f.filename,raw); chunks=ingest.chunk_text(text)
    except Exception as e: return jsonify({"error":str(e)}),400
    if not chunks: return jsonify({"error":"No readable text was found."}),400
    did=db.create_document(uid(),Path(f.filename).name)
    db.insert_chunks(did,chunks); retrieval.build_index(did)
    db.log_activity(uid(),"document_upload",did,minutes=2)
    return jsonify({"document_id":did,"title":Path(f.filename).name,"chunks":len(chunks)})

@app.get("/api/search")
@login_required
def search():
    q=(request.args.get("q") or "").strip().lower()
    if not q: return jsonify({"results":[]})
    results=[]
    for d in db.list_documents(uid()):
        if q in d["title"].lower(): results.append({"type":"document","title":d["title"],"id":d["id"]})
        for n in db.list_notes(uid()):
            if q in n["title"].lower() or q in n["content"].lower():
                results.append({"type":"note","title":n["title"],"id":n["id"]})
                break
    return jsonify({"results":results[:20]})

@app.post("/api/chat")
@login_required
def chat():
    data=request.get_json(force=True); question=(data.get("question") or "").strip()
    if not question: return jsonify({"error":"Question is required."}),400
    try: d=require_doc(data.get("document_id"))
    except ValueError as e: return jsonify({"error":str(e)}),400
    chunks=context_for(d["id"],question,8) or []
    p=db.get_profile(uid()); history=db.chat_history(uid(),d["id"]) or []
    try: answer=llm_client.tutor(question,[c["text"] for c in chunks],history,p,data.get("mode","normal"))
    except llm_client.LLMError as e: return jsonify({"error":str(e)}),502
    db.add_chat(uid(),d["id"],"user",question); db.add_chat(uid(),d["id"],"assistant",answer)
    db.log_activity(uid(),"ai_tutor",d["id"],minutes=3)
    return jsonify({"answer":answer,"sources":[{"chunk_index":c["chunk_index"],"excerpt":c["text"][:240]} for c in chunks]})

@app.post("/api/notes")
@login_required
def notes():
    data=request.get_json(force=True); req=(data.get("request") or "Create detailed study notes from this document.").strip()
    try: d=require_doc(data.get("document_id"))
    except ValueError as e: return jsonify({"error":str(e)}),400
    p=db.get_profile(uid())
    chunks=context_for(d["id"],req,10) or []
    try: content=llm_client.notes([c["text"] for c in chunks],req,p)
    except llm_client.LLMError as e: return jsonify({"error":str(e)}),502
    title=data.get("title") or f"Notes — {d['title']}"
    nid=db.create_note(uid(),d["id"],title,content); db.log_activity(uid(),"notes_generated",d["id"],minutes=5)
    return jsonify({"id":nid,"title":title,"content":content})

@app.get("/api/notes")
@login_required
def notes_list():
    return jsonify({"notes":[dict(x) for x in db.list_notes(uid())]})

@app.post("/api/flashcards")
@login_required
def flashcards():
    data=request.get_json(force=True)
    try: d=require_doc(data.get("document_id"))
    except ValueError as e: return jsonify({"error":str(e)}),400
    count=max(5,min(20,int(data.get("count",10))))
    chunks=context_for(d["id"],None,14) or []
    try: cards=llm_client.flashcards([c["text"] for c in chunks],count)
    except (llm_client.LLMError,ValueError) as e: return jsonify({"error":str(e)}),502
    for c in cards:
        db_c=c
        # persistence is intentionally simple; a generated deck can be recreated.
        db_c
    db.log_activity(uid(),"flashcards_generated",d["id"],minutes=5)
    return jsonify({"cards":cards})

@app.post("/api/quiz/generate")
@login_required
def quiz_generate():
    data=request.get_json(force=True)
    try: d=require_doc(data.get("document_id"))
    except ValueError as e: return jsonify({"error":str(e)}),400
    count=max(5,min(20,int(data.get("count",10))))
    difficulty=data.get("difficulty","medium")
    try: qid=quiz_module.generate(uid(),d["id"],count,difficulty)
    except (ValueError,llm_client.LLMError) as e: return jsonify({"error":str(e)}),502
    db.log_activity(uid(),"quiz_generated",d["id"],minutes=2)
    return jsonify({"quiz_id":qid})

@app.get("/api/quiz/<int:qid>")
@login_required
def quiz_get(qid):
    quiz,qs=db.get_quiz(uid(),qid)
    if not quiz:return jsonify({"error":"Quiz not found."}),404
    return jsonify({"quiz_id":qid,"difficulty":quiz["difficulty"],"questions":[
        {"id":q["id"],"question":q["question"],"options":json.loads(q["options_json"]),
         "correct_index":q["correct_index"],
         "answered":q["student_answer"] is not None}
        for q in qs]})

@app.post("/api/quiz/<int:qid>/answer")
@login_required
def quiz_answer(qid):
    data=request.get_json(force=True)
    try: ans=int(data["answer"])
    except: return jsonify({"error":"Choose an option."}),400
    result=db.answer_question(uid(),qid,int(data["question_id"]),ans)
    if result is None:return jsonify({"error":"Question not found."}),404
    # Topic is not exposed to the client in this MVP; derive it from question text for a stable tracker label.
    quiz,qs=db.get_quiz(uid(),qid)
    answered_q=next((x for x in qs if x["id"]==int(data["question_id"])),None)
    if answered_q:
        db.update_topic(uid(), answered_q["topic"] or "General", bool(result))
    db.log_activity(uid(),"quiz_answered",quiz["document_id"],topic=(answered_q["topic"] if answered_q else "General"),minutes=1)
    db.award_badges(uid())
    return jsonify({"correct":bool(result)})

@app.get("/api/quiz/<int:qid>/result")
@login_required
def quiz_result(qid):
    quiz,qs=db.get_quiz(uid(),qid)
    if not quiz:return jsonify({"error":"Quiz not found."}),404
    answered=[q for q in qs if q["answered_correct"] is not None]
    correct=sum(q["answered_correct"] for q in answered)
    return jsonify({"total":len(qs),"answered":len(answered),"correct":correct,
                    "percentage":round(correct*100/len(answered)) if answered else 0,
                    "details":[{"id":q["id"],"question":q["question"],"options":json.loads(q["options_json"]),
                                "correct_index":q["correct_index"],"student_answer":q["student_answer"],
                                "correct":q["answered_correct"],"explanation":q["explanation"]} for q in qs]})

@app.post("/api/planner")
@login_required
def planner():
    data=request.get_json(force=True)
    try: days=max(1,min(30,int(data.get("days",5)))); minutes=max(10,min(600,int(data.get("minutes",120))))
    except: return jsonify({"error":"Invalid planner settings."}),400
    start=data.get("start_date")
    try:
        sd=datetime.date.fromisoformat(start)
        if sd<datetime.date.today(): return jsonify({"error":"Past dates cannot be selected."}),400
    except: return jsonify({"error":"Choose a valid start date."}),400
    try: d=require_doc(data.get("document_id"))
    except ValueError as e: return jsonify({"error":str(e)}),400
    p=db.get_profile(uid()); chunks=context_for(d["id"],None,14) or []
    try: plan=llm_client.planner([c["text"] for c in chunks],days,start,minutes,p)
    except (llm_client.LLMError,ValueError) as e: return jsonify({"error":str(e)}),502
    # Validate dates and replace model dates with canonical server dates.
    # Be defensive: AI providers can occasionally return null/None instead of
    # the expected list. Treat that as an empty plan and fill safe defaults.
    if not isinstance(plan, list):
        plan = []
    fixed=[]
    for i,item in enumerate(plan[:days],1):
        if not isinstance(item, dict):
            item = {}
        tasks = item.get("tasks")
        if not isinstance(tasks, list):
            tasks = ["Review notes", "Practice questions", "Flashcards"]
        fixed.append({"day":i,"date":str(sd+datetime.timedelta(days=i-1)),
                      "title":item.get("title") or "Study session","minutes":minutes,
                      "tasks":tasks})
    while len(fixed)<days:
        i=len(fixed)+1; fixed.append({"day":i,"date":str(sd+datetime.timedelta(days=i-1)),
          "title":"Revision and practice","minutes":minutes,"tasks":["Review notes","Practice questions","Flashcards"]})
    pid=db.create_note(uid(),d["id"],f"Study Plan — {days} Days",json.dumps(fixed))
    db.log_activity(uid(),"planner_created",d["id"],minutes=2)
    return jsonify({"plan_id":pid,"plan":fixed})

@app.get("/api/ai-status")
@login_required
def ai_status():
    # Safe diagnostic: never returns the API key itself.
    return jsonify(llm_client.check_nvidia_access())

@app.get("/api/dashboard")
@login_required
def dashboard():
    return jsonify(db.dashboard(uid()))

@app.get("/api/topics")
@login_required
def topics():
    return jsonify({"topics":[dict(x) for x in db.topic_stats(uid())]})

@app.get("/api/coach")
@login_required
def coach():
    p=db.get_profile(uid()); dash=db.dashboard(uid()); topics=db.topic_stats(uid())
    try: text=llm_client.coach(p,dash,topics)
    except llm_client.LLMError as e:return jsonify({"error":str(e)}),502
    db.log_activity(uid(),"ai_coach",minutes=2)
    return jsonify({"answer":text})

def markdown_to_text(md):
    md=re.sub(r"^#{1,6}\s*","",md,flags=re.M)
    md=re.sub(r"\*\*(.*?)\*\*",r"\1",md)
    md=re.sub(r"`(.*?)`",r"\1",md)
    return md

@app.get("/api/notes/<int:nid>/download")
@login_required
def download_note(nid):
    fmt=request.args.get("format","pdf").lower()
    c=db.get_conn(); n=c.execute("SELECT * FROM notes WHERE id=? AND user_id=?",(nid,uid())).fetchone(); c.close()
    if not n:return jsonify({"error":"Note not found."}),404
    content=markdown_to_text(n["content"])
    if fmt=="docx":
        from docx import Document
        from docx.shared import Pt
        doc=Document(); doc.add_heading(n["title"],0)
        for para in content.split("\n"):
            if para.strip(): doc.add_paragraph(para.strip())
        path=Path("studyai_note.docx"); doc.save(path)
        return send_file(path,as_attachment=True,download_name=f"{n['title']}.docx")
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.units import mm
    path=Path("studyai_note.pdf")
    styles=getSampleStyleSheet(); styles["Title"].alignment=TA_CENTER
    story=[Paragraph(n["title"],styles["Title"]),Spacer(1,8*mm)]
    for line in content.split("\n"):
        line=line.strip()
        if not line: story.append(Spacer(1,3*mm)); continue
        story.append(Paragraph(line.replace("&","&amp;"),styles["BodyText"]))
    SimpleDocTemplate(str(path),pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=18*mm,bottomMargin=18*mm).build(story)
    return send_file(path,as_attachment=True,download_name=f"{n['title']}.pdf")

@app.get("/api/planner/download")
@login_required
def planner_download():
    # Use the most recent planner note (created by /api/planner).
    c=db.get_conn(); n=c.execute("""SELECT * FROM notes WHERE user_id=? AND title LIKE 'Study Plan — %'
                                    ORDER BY created_at DESC LIMIT 1""",(uid(),)).fetchone(); c.close()
    if not n:return jsonify({"error":"Create a study plan first."}),404
    plan=json.loads(n["content"])
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    path=Path("studyai_plan.pdf"); styles=getSampleStyleSheet()
    story=[Paragraph(n["title"],styles["Title"]),Spacer(1,8*mm)]
    for day in plan:
        story += [Paragraph(f"Day {day['day']} — {day['date']}",styles["Heading2"]),
                  Paragraph(day["title"],styles["Heading3"]),
                  Paragraph(f"Study time: {day['minutes']} minutes",styles["BodyText"])]
        for task in day["tasks"]: story.append(Paragraph("• "+str(task),styles["BodyText"]))
        story.append(Spacer(1,6*mm))
    SimpleDocTemplate(str(path),pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=18*mm,bottomMargin=18*mm).build(story)
    return send_file(path,as_attachment=True,download_name="StudyAI_Study_Plan.pdf")

if __name__=="__main__":
    app.run(debug=os.getenv("STUDYAI_DEBUG","0") == "1", port=5001)
