# StudyAI — Fixed TYBSc CS MVP

This build keeps the existing Flask + SQLite architecture so you can run it on Windows without setting up PostgreSQL.

## Included working modules

- Login / signup with hashed passwords and session authentication
- Per-user document isolation
- PDF/TXT/Markdown upload and TF-IDF retrieval
- Document-aware AI Tutor with Normal, Simple, Detailed, Exam and Compare modes
- Personalized tutor context from the student's profile
- AI Notes Generator
- PDF and DOCX note downloads
- Four-option interactive AI quiz
- Correct/incorrect visual feedback and explanations
- Quiz score and accuracy tracking
- AI Flashcards
- Configurable multi-day AI Study Planner with past-date blocking
- Study Tracker, streaks and badges
- Weak-topic tracking from quiz answers
- AI Study Coach
- Global search foundation
- Responsive single-page interface
- Loading/error/success feedback
- No unnecessary "Ready" status label

## Windows setup

```powershell
cd StudyAI_MVP
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Put your NVIDIA NIM API key in `.env`.

```env
NVIDIA_API_KEY=YOUR_KEY
STUDYAI_GEN_MODEL=openai/gpt-oss-120b
SECRET_KEY=replace-with-a-long-random-secret
```

Run:

```powershell
python app.py
```

Open:

```text
http://127.0.0.1:5001
```

### Important

This release intentionally uses SQLite for the TYBSc project so it is zero-setup. The app automatically adds the new quiz topic column to an older database. If you want a completely clean demo database, stop the app and delete `studyai.db`; it will be recreated automatically.

Do not commit `.env` or your API key.


## NVIDIA AI configuration

This version uses NVIDIA NIM's OpenAI-compatible chat-completions endpoint (`https://integrate.api.nvidia.com/v1/chat/completions`). Set `NVIDIA_API_KEY` in `.env`. The default model is `openai/gpt-oss-120b`.

The AI client retries temporary rate-limit/server failures and shows a friendly application error instead of exposing raw API responses.

The AI Tutor composer uses a compact arrow send button; the text input now takes the available width instead of the Send button stretching across the page.


## NVIDIA HTTP 410 troubleshooting

StudyAI uses NVIDIA's OpenAI-compatible endpoint at `https://integrate.api.nvidia.com/v1/chat/completions`. The default model is `openai/gpt-oss-120b`, with `stepfun-ai/step-3.7-flash` and `meta/llama-3.3-70b-instruct` as fallbacks. If every model returns HTTP 410, the NVIDIA account/organization likely does not have Public API Endpoints inference enabled; enable that permission in NVIDIA Build and restart the app.


## If NVIDIA still returns HTTP 410

This release includes `test_nvidia.py`. Run:

```powershell
python test_nvidia.py
```

If `/v1/models` returns `200` but `/v1/chat/completions` returns `410`, the API key is valid but the NVIDIA organization does not currently have hosted/Public API inference provisioned. Changing the model in StudyAI will not fix that account-level restriction. NVIDIA's current developer forum has multiple August 2026 reports of exactly this pattern. Enable Public API Endpoints/hosted inference for the organization in NVIDIA Build (or ask NVIDIA support to enable it), create a fresh key afterward, and restart the app.

The app also exposes a safe diagnostic at `/api/ai-status` while logged in; it never returns the API key.
